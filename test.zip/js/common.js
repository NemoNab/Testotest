$(function() {

	//SVG Fallback
	if(!Modernizr.svg) {
		$("img[src*='svg']").attr("src", function() {
			return $(this).attr("src").replace(".svg", ".png");
		});
	};

	//Chrome Smooth Scroll
	try {
		$.browserSelector();
		if($("html").hasClass("chrome")) {
			$.smoothScroll();
		}
	} catch(err) {

	};

	$("img, a").on("dragstart", function(event) { event.preventDefault(); });

});


$(".header-block").clone().appendTo(".mhb")
$(".hero-img").clone().appendTo(".hmin")
$(".money-img").clone().appendTo(".monmin")

$('.item.сс1').clone().appendTo('.item-mob.cc1')
$('.item.сс2').clone().appendTo('.item-mob.cc2')
$('.item.сс3').clone().appendTo('.item-mob.cc3')

$("span").removeClass(".hidden")

$('form').each(function() {  // attach to all form elements on page
	$(this).validate({
		rules: {
			name: {
				required: true
			},
			email: {
				email: true,
				required: true
			},
			checkbox: {
				required: true
			}
		},
		tooltip_options: {
			email: {
				placement: 'top',
				trigger: 'focus'
			},
			name: {
				placement: 'top'
			},
			checkbox: {
				placement: 'top'
			}
		},
		submitHandler: function(form) {
			$.ajax({
				type: "POST",
				url: "/mail.php",
				data: $(form).serialize(),
				timeout: 3000,
				success: function() {
					$('form').trigger( 'reset' );
					$('span').removeClass('hidden');
				},
				error: function() {
					$('form').reset();
					$(".modalContForm").hide();
					$(".contForm").hide();
					$("h2.form").hide();
					$('.form-pad').append('<h2 class="form">Произошла ошибка, повторите попытку позже.</h2>')
				}
			});
			return false;
		}
	})
});



$(window).load(function() {

	$(".loader_inner").fadeOut();
	$(".loader").delay(400).fadeOut("slow");

});
